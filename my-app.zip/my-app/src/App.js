import React, { Component } from "react";
import "./App.css";
import axios from "axios";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currencies: [],
    };
  }

  componentDidMount() {
    axios.get("https://api.coinbase.com/v2/currencies").then((res) => {
      const currencies = res.data.data;
      this.setState({ currencies });
    });
  }

  render() {
    return (
      <div className="App">
        <h1>Coinbase API</h1>
        <ul>
          {this.state.currencies.map((currency) => (
            <li key={currency.id}>{currency.name}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default App;
